Plugin API
==========

.. automodule:: neutron.neutron_plugin_base_v2

.. autoclass:: NeutronPluginBaseV2
    :members:
