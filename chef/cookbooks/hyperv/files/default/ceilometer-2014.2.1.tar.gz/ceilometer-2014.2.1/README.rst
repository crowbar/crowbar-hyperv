ceilometer
==========

See the ReleaseNotes document and the project home for more info.

  http://launchpad.net/ceilometer
